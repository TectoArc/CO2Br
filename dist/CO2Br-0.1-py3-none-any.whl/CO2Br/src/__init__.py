__all__ = ["pvtx", "solubility", "viscosity"]
from CO2Br.src.pvtx import *
from CO2Br.src.solubility import *
from CO2Br.src.viscosity import *